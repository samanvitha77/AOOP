package TASK2;

public interface MusicPlayer {
    void playMusic(String sourceDetails);
}
