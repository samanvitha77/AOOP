package TASK2;

public interface MusicSource {
    String getSourceName();
    String getSourceDetails();
}
