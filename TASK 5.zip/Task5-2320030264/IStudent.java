// IStudent.java
public interface IStudent {
    String getName();
    String getId();
    void enrollInCourse(ICourse course);
}
