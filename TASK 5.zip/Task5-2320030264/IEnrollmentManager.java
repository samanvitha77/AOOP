// IEnrollmentManager.java
public interface IEnrollmentManager {
    void enrollStudentInCourse(IStudent student, ICourse course);
}
