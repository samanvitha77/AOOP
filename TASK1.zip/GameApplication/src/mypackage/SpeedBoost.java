package mypackage;

public class SpeedBoost implements Powerup{
	public void activate() {
        System.out.println("Increasing speed!");
    }

}
