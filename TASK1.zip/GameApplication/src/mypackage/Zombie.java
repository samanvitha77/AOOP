package mypackage;

public class Zombie extends Enemy {
	public void attack() {
        System.out.println("Zombie attacks with claws!");
    }
}
