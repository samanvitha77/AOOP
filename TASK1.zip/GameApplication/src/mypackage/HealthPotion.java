package mypackage;

public class HealthPotion implements Powerup{
	public void activate() {
        System.out.println("Restoring health!");
    }

}
