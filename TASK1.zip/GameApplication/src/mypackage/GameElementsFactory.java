package mypackage;

public interface GameElementsFactory {
	Weapon createWeapon();
    Powerup createPowerUp();

}
