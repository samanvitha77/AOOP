package mypackage;

public class Sword implements Weapon{
	public void use() {
        System.out.println("Swinging the sword!");
    }

}
