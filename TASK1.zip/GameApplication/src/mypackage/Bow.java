package mypackage;

public class Bow implements Weapon{
	public void use() {
        System.out.println("Shooting an arrow!");
    }

}
