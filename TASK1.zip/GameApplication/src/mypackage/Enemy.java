package mypackage;

abstract class Enemy {
	public abstract void attack();
}
